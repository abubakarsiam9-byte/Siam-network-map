-- Siam Network Map v9 migration
alter table public.fiber_lines add column if not exists description text default '';

drop policy if exists "fiber_lines_select_auth" on public.fiber_lines;
drop policy if exists "fiber_lines_insert_auth" on public.fiber_lines;
drop policy if exists "fiber_lines_update_owner_admin" on public.fiber_lines;
drop policy if exists "fiber_lines_delete_owner_admin" on public.fiber_lines;
create policy "fiber_lines_select_auth" on public.fiber_lines for select to authenticated using (true);
create policy "fiber_lines_insert_auth" on public.fiber_lines for insert to authenticated with check (created_by=auth.uid());
create policy "fiber_lines_update_owner_admin" on public.fiber_lines for update to authenticated using (created_by=auth.uid() or exists(select 1 from public.staff_profiles s where s.id=auth.uid() and s.role='admin' and coalesce(s.is_locked,false)=false));
create policy "fiber_lines_delete_owner_admin" on public.fiber_lines for delete to authenticated using (created_by=auth.uid() or exists(select 1 from public.staff_profiles s where s.id=auth.uid() and s.role='admin' and coalesce(s.is_locked,false)=false));
create or replace function public.admin_set_staff_role(target_user_id uuid,new_role text) returns boolean language plpgsql security definer set search_path=public as $$ declare caller_role text; begin select role into caller_role from public.staff_profiles where id=auth.uid() and coalesce(is_locked,false)=false; if caller_role<>'admin' then raise exception 'Only admin can change roles'; end if; if new_role not in ('staff','admin') then raise exception 'Invalid role'; end if; update public.staff_profiles set role=new_role where id=target_user_id; return found; end; $$;
revoke all on function public.admin_set_staff_role(uuid,text) from public; grant execute on function public.admin_set_staff_role(uuid,text) to authenticated;

-- Mark the original admin as owner. Run once.
alter table public.staff_profiles add column if not exists is_owner boolean not null default false;
update public.staff_profiles set is_owner=true where id=(select id from auth.users order by created_at asc limit 1);

create or replace function public.admin_set_staff_role(target_user_id uuid,new_role text) returns boolean language plpgsql security definer set search_path=public as $$ declare caller_role text; target_owner boolean; begin select role into caller_role from public.staff_profiles where id=auth.uid() and coalesce(is_locked,false)=false; if caller_role<>'admin' then raise exception 'Only admin can change roles'; end if; select coalesce(is_owner,false) into target_owner from public.staff_profiles where id=target_user_id; if target_owner then raise exception 'Main admin cannot be changed'; end if; if new_role not in ('staff','admin') then raise exception 'Invalid role'; end if; update public.staff_profiles set role=new_role where id=target_user_id; return found; end; $$;
