import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cors={"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type","Access-Control-Allow-Methods":"POST, OPTIONS"};

Deno.serve(async (req)=>{
  if(req.method==='OPTIONS') return new Response('ok',{headers:cors});
  try{
    const auth=req.headers.get('Authorization')||'';
    const token=auth.replace(/^Bearer\\s+/i,'');
    if(!token) throw new Error('Missing authorization');
    const url=Deno.env.get('SUPABASE_URL')!;
    const service=Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const admin=createClient(url,service);
    const {data:{user:caller},error:callerErr}=await admin.auth.getUser(token);
    if(callerErr||!caller) throw new Error('Invalid session');
    const {data:profile}=await admin.from('staff_profiles').select('role,is_locked,is_owner').eq('id',caller.id).maybeSingle();
    if(profile?.role!=='admin'||profile?.is_locked) throw new Error('Only an unlocked admin can create accounts');

    const body=await req.json();
    const name=String(body.name||'').trim();
    const email=String(body.email||'').trim().toLowerCase();
    const password=String(body.password||'');
    const role=body.role==='admin'?'admin':'staff';
    if(!email||password.length<6) throw new Error('Email and password (6+ chars) are required');

    const {data:newUser,error:createErr}=await admin.auth.admin.createUser({email,password,email_confirm:true,user_metadata:{name}});
    if(createErr) throw createErr;
    const {error:profileErr}=await admin.from('staff_profiles').upsert({id:newUser.user.id,email,name:name||email,role,is_locked:false,last_active_at:null});
    if(profileErr){await admin.auth.admin.deleteUser(newUser.user.id);throw profileErr;}
    return new Response(JSON.stringify({ok:true,user_id:newUser.user.id}),{headers:{...cors,'Content-Type':'application/json'}});
  }catch(e){
    return new Response(JSON.stringify({error:e?.message||String(e)}),{status:400,headers:{...cors,'Content-Type':'application/json'}});
  }
});
